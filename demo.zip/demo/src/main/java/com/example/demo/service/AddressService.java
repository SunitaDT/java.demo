package com.example.demo.service;

import com.example.demo.entity.Address;
import com.example.demo.entity.Employee;
import com.example.demo.repository.AddressRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AddressService {

    @Autowired
    private AddressRepository addressRepository;

    public void save(Address address) {
        addressRepository.save(address);
    }

    public void update(Address address) {
        addressRepository.save(address);
    }

    public void delete(Integer id) {
        addressRepository.deleteById(id);
    }

    public Address getById(Integer id) {
        return addressRepository.findById(id).orElse(null);
    }

    public List<Address> getAll() {
        return addressRepository.findAll();
    }
}
