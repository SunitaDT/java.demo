package com.example.demo.controller;

import com.example.demo.entity.Address;
import com.example.demo.entity.ResponseDTO;
import com.example.demo.service.AddressService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/address/")
public class AddressController {

    @Autowired
    private AddressService addressService;

    @PostMapping(value = "save")
    public ResponseEntity<ResponseDTO> save(@RequestBody Address address) {
        ResponseDTO response = null;
       try{
           addressService.save(address);
           response = new ResponseDTO(HttpStatus.OK.value(), "Saved Successful", null);
       } catch (Exception e) {
           response = new ResponseDTO(HttpStatus.INTERNAL_SERVER_ERROR.value(),"Saved failed",null );
       }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PutMapping(value = "update")
    public ResponseEntity<ResponseDTO> update(@RequestBody Address address) {
        ResponseDTO response = null;
        try{
            addressService.update(address);
            response = new ResponseDTO(HttpStatus.OK.value(), "Update Successful", null);
        } catch (Exception e) {
            response = new ResponseDTO(HttpStatus.INTERNAL_SERVER_ERROR.value(),"Update failed",null );
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @DeleteMapping(value = "delete/{id}")
    public ResponseEntity<ResponseDTO> delete(@PathVariable("id") Integer id) {
        ResponseDTO response = null;
        try{
            addressService.delete(id);
            response = new ResponseDTO(HttpStatus.OK.value(), "Delete Successful", null);
        } catch (Exception e) {
            response = new ResponseDTO(HttpStatus.INTERNAL_SERVER_ERROR.value(),"Delete failed",null );
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping(value = "getById/{id}")
    public ResponseEntity<ResponseDTO> getById(@PathVariable("id") Integer id) {
        ResponseDTO response = null;
        try{
            Address address = addressService.getById(id);
            response = new ResponseDTO(HttpStatus.OK.value(), "Fetch Successful", address);
        } catch (Exception e) {
            response = new ResponseDTO(HttpStatus.INTERNAL_SERVER_ERROR.value(),"Fetch failed",null );
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping(value = "getAll")
    public ResponseEntity<ResponseDTO> getById() {
        ResponseDTO response = null;
        try{
            List<Address> address = addressService.getAll();
            response = new ResponseDTO(HttpStatus.OK.value(), "Fetch Successful", address);
        } catch (Exception e) {
            response = new ResponseDTO(HttpStatus.INTERNAL_SERVER_ERROR.value(),"Fetch failed",null );
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
