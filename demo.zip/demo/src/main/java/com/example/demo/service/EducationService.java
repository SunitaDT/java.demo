package com.example.demo.service;

import com.example.demo.entity.Education;
import com.example.demo.repository.EducationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EducationService {

    @Autowired
    private EducationRepository educationRepository;

    public void save(Education education) {
        educationRepository.save(education);
    }

    public void update(Education education) {
        educationRepository.save(education);
    }

    public void delete(Integer id) {
        educationRepository.deleteById(id);
    }

    public Education getById(Integer id) {
        return educationRepository.findById(id).orElse(null);
    }

    public List<Education> getAll() {
        return educationRepository.findAll();
    }
}
