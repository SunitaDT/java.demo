package com.example.demo.controller;

import com.example.demo.entity.Department;
import com.example.demo.entity.Dependants;
import com.example.demo.entity.ResponseDTO;
import com.example.demo.service.DependantsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/dependants/")
public class DependantsController {

    @Autowired
    private DependantsService dependantsService;

    @PostMapping(value = "save")
    public ResponseEntity<ResponseDTO> save(@RequestBody Dependants dependants) {
        ResponseDTO response = null;
        try{
            dependantsService.save(dependants);
            response = new ResponseDTO(HttpStatus.OK.value(), "Saved Successful", null);
        } catch (Exception e) {
            response = new ResponseDTO(HttpStatus.INTERNAL_SERVER_ERROR.value(),"Saved failed",null );
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PutMapping(value = "update")
    public ResponseEntity<ResponseDTO> update(@RequestBody Dependants dependants) {
        ResponseDTO response = null;
        try{
            dependantsService.update(dependants);
            response = new ResponseDTO(HttpStatus.OK.value(), "Update Successful", null);
        } catch (Exception e) {
            response = new ResponseDTO(HttpStatus.INTERNAL_SERVER_ERROR.value(),"Update failed",null );
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @DeleteMapping(value = "delete/{id}")
    public ResponseEntity<ResponseDTO> delete(@PathVariable("id") Integer id) {
        ResponseDTO response = null;
        try{
            dependantsService.delete(id);
            response = new ResponseDTO(HttpStatus.OK.value(), "Delete Successful", null);
        } catch (Exception e) {
            response = new ResponseDTO(HttpStatus.INTERNAL_SERVER_ERROR.value(),"Delete failed",null );
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping(value = "getById/{id}")
    public ResponseEntity<ResponseDTO> getById(@PathVariable("id") Integer id) {
        ResponseDTO response = null;
        try{
            Dependants dependants = dependantsService.getById(id);
            response = new ResponseDTO(HttpStatus.OK.value(), "Fetch Successful", dependants);
        } catch (Exception e) {
            response = new ResponseDTO(HttpStatus.INTERNAL_SERVER_ERROR.value(),"Fetch failed",null );
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping(value = "getAll")
    public ResponseEntity<ResponseDTO> getById() {
        ResponseDTO response = null;
        try{
            List<Dependants> dependants = dependantsService.getAll();
            response = new ResponseDTO(HttpStatus.OK.value(), "Fetch Successful", dependants);
        } catch (Exception e) {
            response = new ResponseDTO(HttpStatus.INTERNAL_SERVER_ERROR.value(),"Fetch failed",null );
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
