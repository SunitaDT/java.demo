package com.example.demo.service;

import com.example.demo.entity.Dependants;
import com.example.demo.entity.Employee;
import com.example.demo.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    public void save(Employee employee) {
        employeeRepository.save(employee);
    }

    public void update(Employee employee) {
        employeeRepository.save(employee);
    }

    public void delete(Integer id) {
        employeeRepository.deleteById(id);
    }

    public Employee getById(Integer id) {
        return employeeRepository.findById(id).orElse(null);
    }

    public List<Employee> getAll() {
        return employeeRepository.findAll();
    }
}
