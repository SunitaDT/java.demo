package com.example.demo.service;

import com.example.demo.entity.Department;
import com.example.demo.entity.Employee;
import com.example.demo.repository.DepartmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DepertmentService {

    @Autowired
    private DepartmentRepository departmentRepository;

    public void save(Department department) {
        departmentRepository.save(department);
    }

    public void update(Department department) {
        departmentRepository.save(department);
    }

    public void delete(Integer id) {
        departmentRepository.deleteById(id);
    }

    public Department getById(Integer id) {
        return departmentRepository.findById(id).orElse(null);
    }

    public List<Department> getAll() {
        return departmentRepository.findAll();
    }
}
