package com.example.demo.service;

import com.example.demo.entity.Dependants;
import com.example.demo.entity.Education;
import com.example.demo.repository.DependantsRepository;
import com.example.demo.repository.EducationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DependantsService {

    @Autowired
    private DependantsRepository dependantsRepository;

    public void save(Dependants dependants) {
        dependantsRepository.save(dependants);
    }

    public void update(Dependants dependants) {
        dependantsRepository.save(dependants);
    }

    public void delete(Integer id) {
        dependantsRepository.deleteById(id);
    }

    public Dependants getById(Integer id) {
        return dependantsRepository.findById(id).orElse(null);
    }

    public List<Dependants> getAll() {
        return dependantsRepository.findAll();
    }
}
